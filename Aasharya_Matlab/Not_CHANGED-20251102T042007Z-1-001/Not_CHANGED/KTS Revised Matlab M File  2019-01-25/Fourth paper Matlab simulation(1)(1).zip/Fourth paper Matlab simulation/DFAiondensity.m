    Q=Ze*dt/Mi;                                                   % Defined for simplicity
for T=1:ntra                                                      % Calculate for 1-ntra
    m = 1;                                                        % Initializing time counter
    vxL = VLi(T);                                                 % Ion velocity for the slected trajectory at injection
    Vxm = vxL;                                                    % The initial value of x-component velocity at sheath edge                                        
    Vym = -5.6160e+005;                                                   % The value of y-component velocity
    Vzm = -5.6160e+005;                                                   % The value of z-component velocity
    Vxmplus14 = Vxm +0.25*Q*DFAEfield(L)-0.25*Q*B0*Vzm*sin(Theta); % Value of x-component velocity after at (dt/4) time 
    Xmplushalf = L + 0.5*dt*Vxmplus14;                             % Value of postion(X) moving after (dt/t) time
    Vymplus14 = Vym + 0.25*Q*B0*Vzm*cos(Theta);                    % Value of y-component velocity moving by (dt/4) time
    Vzmplushalf = Vzm + 0.5*Q*B0*(Vxmplus14*sin(Theta) - Vymplus14*cos(Theta)) ; % Value of z-component velocity moving by (dt/4) time 
    
    Vxm(m) = Vxm;                                                   % storing the value
    Vym(m) = Vym;                                                   % storing the value
    Vzm(m) = Vzm;                                                   % storing the value
    Xm2(m) = Xmplushalf;                                            % storing the value
    Vm2(m)= Vxm;                                                    % storing the value
  
   if Xm2(m) <= X(nx-1)                                            % Done only if Xm2(m) <= X(nx-1)   
        disp('Time step is too large. Press a key to continue.')
         pause                                                      % Stop if not valid condition
    end    % End the loop if Xm2(m) <= X(nx-1)
 while Xm2(m)>0 & Xm2(m)<=L                                         % solving the equation of motion until the ion crosses x=0 or x=L
        for m=m+1                                                   % Next time step
            Vxm(m) = Vxm(m-1) + Q*DFAEfield(Xm2(m-1))- Q*B0*Vzm(m-1)*sin(Theta); % Value of x-component velocity moving after dt time
            Vym(m) = Vym(m-1) + Q*B0*Vzm(m-1)*cos(Theta);                        % Value of y-component velocity moving after dr time
            Vxmminushalf = 0.5*(Vxm(m) + Vxm(m-1));                              % Value of x-component velocity at half integral centred
            Vymminushalf = 0.5*(Vym(m) + Vym(m-1));                              % Value of y-component velocity at half integral centred 
            Vzm(m)  = Vzm(m-1) + Q*B0*(Vxmminushalf*sin(Theta) - Vymminushalf*cos(Theta)) ; % Value of z-component moving after dt time
            Xm2(m) = Xm2(m-1) + dt*Vxm(m);                                       % Value of position at half integral time centred
            Vm2(m)=0.5*(Vxm(m)+Vxm(m-1)); % Value of x-component velocity at half time centred
        
        end                                                                      % End the calculation for m=m+1
 end                                                                             %Done regularly & end while Xm2(m)>0 & Xm2(m)<=L
    Xt=[L,Xm2(1:m-1)];                                                           % Position along the trajectory in matrix forms of half integral time centred
    Vt=Vm2;                                                                      %  Corresponding velocity at half integral time centred  position 
    a=((Xt(m-2)-Xt(m))^2*(Vt(m-1)-Vt(m-2))-(Xt(m-2)-Xt(m-1))^2*(Vt(m)-Vt(m-2)))/(Xt(m-2)-Xt(m-1))/(Xt(m-2)-Xt(m))/(Xt(m-1)-Xt(m));
    b=((Xt(m-2)-Xt(m))*(Vt(m-1)-Vt(m-2))-(Xt(m-2)-Xt(m-1))*(Vt(m)-Vt(m-2)))/(Xt(m-2)-Xt(m-1))/(Xt(m-2)-Xt(m))/(Xt(m)-Xt(m-1));
    vx0= Vt(m-2)+ a*Xt(m-2) + b*Xt(m-2)^2;                                        % The velocoty at wall(x=0)
    Xt=[Xt,0];                                                                      
    Vt=[Vt,vx0];                                                         % Position (from x=L to x=0) and the corresponding velocities along the trajectory
    Vti=interp1(Xt,Vt,X);                                                % Interploating for the velocity at fixed grid(x)
    Vi(T,:)=Vti;                                                         % Storing ion velocities at X-grid points for the Tth trajectory as Tth element of matrixVL
    Df(T)=Dfun(VLi(T));                                                  % Distribution function On (vxL=VLi(T))
    clear Vm Vm2 Vt Vti Xm2 Xt a b m r vx0
end                                                                      % End of loop started as:'for T=1:ntra'

% ni calculating without interpolating onto the fixed velocity grid points

   ni=zeros(1,nx);                                                       % Initializing ni
for j=1:nx;                                                              % Selecting j-th grid
   V_xi=Vi(:,j);                                                         % Velocities of all traced trajectoryes through the selected j-th grid point
   for T=1:ntra-1                                                        % Integrating for ion density                                                      
      ni(j)=ni(j)+.5*(Df(T)+Df(T+1))*abs(V_xi(T+1)-V_xi(T));             % Density of ion at j-th grid point  
   end                                                                   % End of the loop started as for j=1:ntra-1                                                         %
end                                                                      % End of the loop started as for j=nx
%Ion kinetic energy calculating 
Ei=zeros(1,nx);
for j=1:nx;
    V_xi=Vi(:,j);
   for T=1:ntra-1
      Ei(j)=Ei(j)+(0.5*0.5*Mi*((Df(T+1)*V_xi(T+1).^2)+(Df(T)*V_xi(T).^2))*abs(V_xi(T+1)-V_xi(T)))./(ni(j)+0.5*(Df(T)+Df(T+1))*abs(V_xi(T+1)-V_xi(T)));
   end
   clear  V_xi T
end 
